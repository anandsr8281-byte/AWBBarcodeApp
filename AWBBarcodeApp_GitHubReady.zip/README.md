# AWB Barcode — GitHub Ready

This project builds an Android APK automatically with GitHub Actions.

## Phone-only build

1. Create a GitHub repository, preferably Private.
2. Upload the CONTENTS of this folder to the repository (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Tap **Run workflow**.
6. Wait for the green check mark.
7. Open the completed workflow run.
8. Scroll to **Artifacts**.
9. Download **AWBBarcode-debug-apk**.
10. Open the downloaded ZIP and extract `app-debug.apk`.
11. Tap the APK to install it. Android may ask you to allow installation from that browser/file manager.

The workflow uses GitHub's hosted Ubuntu runner, JDK 17, Android SDK 35 and Gradle 8.10.2.
