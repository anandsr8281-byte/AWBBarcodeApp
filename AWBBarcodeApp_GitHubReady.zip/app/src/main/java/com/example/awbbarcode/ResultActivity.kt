package com.example.awbbarcode

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.awbbarcode.databinding.ActivityResultBinding
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val awb = intent.getStringExtra("AWB").orEmpty()
        binding.awbText.text = awb
        binding.barcodeImage.setImageBitmap(createBarcode(awb))

        binding.copyButton.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AWB", awb))
            Toast.makeText(this, "AWB copied", Toast.LENGTH_SHORT).show()
        }

        binding.newScanButton.setOnClickListener {
            finish()
        }
    }

    private fun createBarcode(value: String): Bitmap {
        val width = 1000
        val height = 320
        val matrix: BitMatrix = MultiFormatWriter().encode(
            value,
            BarcodeFormat.CODE_128,
            width,
            height,
            emptyMap()
        )
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap.setPixel(
                    x, y,
                    if (matrix[x, y]) android.graphics.Color.BLACK
                    else android.graphics.Color.WHITE
                )
            }
        }
        return bitmap
    }
}
