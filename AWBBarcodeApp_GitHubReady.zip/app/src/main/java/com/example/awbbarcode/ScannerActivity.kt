package com.example.awbbarcode

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.awbbarcode.databinding.ActivityScannerBinding
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ScannerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScannerBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val found = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        startCamera()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.surfaceProvider = binding.previewView.surfaceProvider
            }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(executor) { proxy ->
                if (found.get()) {
                    proxy.close()
                    return@setAnalyzer
                }
                val mediaImage = proxy.image
                if (mediaImage == null) {
                    proxy.close()
                    return@setAnalyzer
                }

                val image = InputImage.fromMediaImage(
                    mediaImage,
                    proxy.imageInfo.rotationDegrees
                )

                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val candidate = extractAwb(result.text)
                        if (candidate != null && found.compareAndSet(false, true)) {
                            runOnUiThread {
                                binding.statusText.text = "AWB found"
                                startActivity(
                                    Intent(this, ResultActivity::class.java)
                                        .putExtra("AWB", candidate)
                                )
                                finish()
                            }
                        }
                    }
                    .addOnCompleteListener { proxy.close() }
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun extractAwb(text: String): String? {
        // Keep letters/numbers and split OCR output into tokens.
        val tokens = text.uppercase()
            .replace(Regex("[^A-Z0-9\\n ]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length >= 6 }

        // Prefer long mixed/alphanumeric tokens, typical for AWB numbers.
        return tokens
            .filter { it.any(Char::isDigit) }
            .filter { it.any(Char::isLetter) || it.all(Char::isDigit) }
            .sortedByDescending { it.length }
            .firstOrNull()
            ?: tokens.firstOrNull()
    }

    override fun onDestroy() {
        recognizer.close()
        executor.shutdown()
        super.onDestroy()
    }
}
